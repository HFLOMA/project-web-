import React, { useState } from "react";
import { Link } from "react-router-dom";

class GaussElimination {
  constructor(Atext, Btext) {
    this.A = Atext.trim().split("\n").map(r => r.trim().split(/\s+/).map(Number));
    this.B = Btext.trim().split(/\s+/).map(Number);
  }

  calculate() {
    const n = this.A.length;
    const A = this.A.map((row, i) => [...row, this.B[i]]); 

    for (let i = 0; i < n; i++) {
  
      if (A[i][i] === 0) {
        for (let k = i + 1; k < n; k++) {
          if (A[k][i] !== 0) {
            [A[i], A[k]] = [A[k], A[i]];
            break;
          }
        }
      }

    
      for (let j = i + 1; j < n; j++) {
        const factor = A[j][i] / A[i][i];
        for (let k = i; k <= n; k++) {
          A[j][k] -= factor * A[i][k];
        }
      }
    }

  
    const X = Array(n).fill(0);
    for (let i = n - 1; i >= 0; i--) {
      let sum = 0;
      for (let j = i + 1; j < n; j++) {
        sum += A[i][j] * X[j];
      }
      X[i] = (A[i][n] - sum) / A[i][i];
    }

    return X;
  }
}

export default function GaussEliminationUI() {
  const [Atext, setAtext] = useState("");
  const [Btext, setBtext] = useState("");
  const [result, setResult] = useState(null);

  const handleCalculate = () => {
    const solver = new GaussElimination(Atext, Btext);
    const res = solver.calculate();
    setResult(res);
  };

  return (
    <div style={{ textAlign: "center", marginTop: 30, fontFamily: "Arial" }}>
      <div style={{ textAlign: "left", marginLeft: "40px", marginBottom: "10px" }}>
        <Link
          to="/"
          style={{
            textDecoration: "none",
            fontSize: "18px",
            fontWeight: "bold",
          }}
        >
          กลับหน้าแรก
        </Link>
      </div>

      <h1 style={{ color: "blueviolet" }}>Gauss Elimination Method</h1>

      <div
        style={{
          display: "flex",
          justifyContent: "center",
          gap: "40px",
          marginTop: "20px",
        }}
      >
        <div>
          <h3>[A]</h3>
          <textarea
            rows="5"
            cols="20"
            value={Atext}
            onChange={(e) => setAtext(e.target.value)}
            placeholder={"2 3 -1\n4 1 2\n1 2 3"}
            style={{
              resize: "none",
              fontSize: "14px",
              padding: "5px",
              textAlign: "center",
            }}
          />
        </div>

        <div>
          <h3>[B]</h3>
          <textarea
            rows="5"
            cols="10"
            value={Btext}
            onChange={(e) => setBtext(e.target.value)}
            placeholder={"5\n6\n7"}
            style={{
              resize: "none",
              fontSize: "14px",
              padding: "5px",
              textAlign: "center",
            }}
          />
        </div>
      </div>

      <button
        onClick={handleCalculate}
        style={{
          marginTop: "20px",
          backgroundColor: "limegreen",
          color: "white",
          border: "none",
          borderRadius: "8px",
          padding: "10px 20px",
          cursor: "pointer",
          fontSize: "16px",
        }}
      >
        คำนวณ
      </button>

      {result && (
        <div style={{ marginTop: 25 }}>
          <h3>ผลลัพธ์</h3>
          {result.map((x, i) => (
            <p key={i}>X{i + 1} = {x.toFixed(4)}</p>
          ))}
        </div>
      )}
    </div>
  );
}

