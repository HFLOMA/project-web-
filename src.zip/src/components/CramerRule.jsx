import React, { useState } from "react";
import * as math from "mathjs";
import { Link } from "react-router-dom";

class CramerCalculator {
  constructor(Atext, Btext) {
    this.A = Atext.trim().split("\n").map(r => r.trim().split(/\s+/).map(Number));
    this.B = Btext.trim().split(/\s+/).map(Number);
  }

  calculate() {
    const A = this.A;
    const B = this.B;
    const detA = math.det(A);
    const results = [];
    const detAi = [];

    for (let i = 0; i < A.length; i++) {
      const Ai = JSON.parse(JSON.stringify(A));
      for (let j = 0; j < A.length; j++) Ai[j][i] = B[j];
      const det = math.det(Ai);
      detAi.push(det);
      results.push(det / detA);
    }

    return { detA, detAi, results };
  }
}

export default function CramerRuleOOP() {
  const [Atext, setAtext] = useState("");
  const [Btext, setBtext] = useState("");
  const [result, setResult] = useState(null);

  const handleCalculate = () => {
    const res = new CramerCalculator(Atext, Btext).calculate();
    setResult(res);
  };

  return (
    <div style={{ textAlign: "center", marginTop: 30, fontFamily: "Arial" }}>
      <div style={{ textAlign: "left", marginLeft: "40px", marginBottom: "10px" }}>
        <Link
          to="/"
          style={{
            textDecoration: "none",
            fontSize: "18px",
            fontWeight: "bold",
          }}
        >
          กลับหน้าแรก
        </Link>
      </div>

      <h1 style={{ color: "blueviolet" }}>Cramer’s Rule</h1>

      <div
        style={{
          display: "flex",
          justifyContent: "center",
          gap: "40px",
          marginTop: "20px",
        }}
      >
        <div>
          <h3>[A]</h3>
          <textarea
            rows="5"
            cols="20"
            value={Atext}
            onChange={(e) => setAtext(e.target.value)}
            placeholder={"2 3 -1\n4 1 2\n1 2 3"}
            style={{
              resize: "none",
              fontSize: "14px",
              padding: "5px",
              textAlign: "center",
            }}
          />
        </div>

        <div>
          <h3>[B]</h3>
          <textarea
            rows="5"
            cols="10"
            value={Btext}
            onChange={(e) => setBtext(e.target.value)}
            placeholder={"5\n6\n7"}
            style={{
              resize: "none",
              fontSize: "14px",
              padding: "5px",
              textAlign: "center",
            }}
          />
        </div>
      </div>

      <button
        onClick={handleCalculate}
        style={{
          marginTop: "20px",
          backgroundColor: "limegreen",
          color: "white",
          border: "none",
          borderRadius: "8px",
          padding: "10px 20px",
          cursor: "pointer",
          fontSize: "16px",
        }}
      >
        คำนวณ
      </button>

      {result && (
        <div style={{ marginTop: 25 }}>
          <h3>ผลลัพธ์</h3>
          <p>Δ = {result.detA.toFixed(4)}</p>
          {result.detAi.map((val, i) => (
            <p key={i}>
             X{i + 1} = {(val / result.detA).toFixed(4)}
            </p>
          ))}
        </div>
      )}

      
    </div>
  );
}
