import React, { Component } from "react";
import FalsePosition from "../../utils/FalsePosition";
import DesmosGraph from "./DesmosGraph";
import { Link } from "react-router-dom";

class FalsePositionMethod extends Component {
  constructor(props) {
    super(props);
    this.state = {
      Equation: "x^3 - 2*x^2 - 5",
      xl: 1,
      xr: 4,
      answer: 0,
      iterations: [],
    };
  }

  handleChange = (e, field) => {
    this.setState({
      [field]:
        e.target.type === "number" ? +e.target.value : e.target.value,
    });
  };

  Calculate = () => {
    const { Equation, xl, xr } = this.state;
    const fp = new FalsePosition(Equation, xl, xr);   
    const { root, steps } = fp.calculate();
    this.setState({ answer: root, iterations: steps });
  };

  render() {
    const { Equation, xl, xr, answer, iterations } = this.state;

    return (
      <div
        style={{
          maxWidth: "1000px",
          margin: "40px auto",
          fontFamily: "Arial, sans-serif",
        }}
      >
        <nav>
          <Link to="/" style={{ margin: "10px", fontSize: 25 }}>
            • กลับหน้าแรก
          </Link>
        </nav>

        <div style={{ textAlign: "center" }}>
          <h1
            style={{
              color: "blueviolet",
              fontSize: "36px",
              fontWeight: "bold",
              marginBottom: "20px",
            }}
          >
            False Position Method 
          </h1>

          <h2>สมการ</h2>
          <input
            type="text"
            value={Equation}
            onChange={(e) => this.handleChange(e, "Equation")}
          />

          <h2>XL</h2>
          <input
            type="number"
            value={xl}
            onChange={(e) => this.handleChange(e, "xl")}
          />

          <h2>XR</h2>
          <input
            type="number"
            value={xr}
            onChange={(e) => this.handleChange(e, "xr")}
          />
            
             <div style={{ marginTop: "20px", textAlign: "center" }}>
  <button
    onClick={this.Calculate}

    style={{
      padding: "12px 25px",
      backgroundColor: "#4CAF50", 
      color: "white",             
      border: "none",            
      borderRadius: "8px",        
      fontSize: "16px",
      fontWeight: "bold",
      cursor: "pointer",          
      boxShadow: "2px 4px 8px rgba(0,0,0,0.2)", 
      transition: "0.3s",        
    }}
  >
    คำนวณ
  </button>
</div>

<h3
  style={{
    fontSize: "30px",
    fontWeight: "bold",
    color: "red",
    textShadow: "2px 2px 5px gray", 
    textAlign: "center",
  }}
>
  คำตอบที่ได้
</h3>
      <h2 style={{ color: "green",fontSize: "30px",fontWeight:"bold",}}>{answer.toFixed(10)}</h2>

       

          {iterations.length > 0 && (
            <table
              border="1"
              cellPadding="5"
              style={{ margin: "20px auto", borderCollapse: "collapse" }}
            >
              <thead style={{ background: "#f2f2f2" }}>
                <tr>
                  <th>Iteration</th>
                  <th>XL</th>
                  <th>XR</th>
                  <th>XM</th>
                  <th>Error</th>
                </tr>
              </thead>
              <tbody>
                {iterations.map((s, i) => (
                  <tr key={i}>
                    <td>{s.iter}</td>
                    <td>{s.xl.toFixed(6)}</td>
                    <td>{s.xr.toFixed(6)}</td>
                    <td>{s.xm.toFixed(6)}</td>
                    <td>
                      {typeof s.error === "string"
                        ? s.error
                        : s.error.toFixed(6)}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}

          <DesmosGraph equation={Equation} points={iterations} />
        </div>
      </div>
    );
  }
}

export default FalsePositionMethod;  