import { useEffect, useRef } from "react";

function DesmosGraph({ equation, points }) {
  const desmosRef = useRef(null);
  const calcRef = useRef(null)

  useEffect(() => {
    if (desmosRef.current && !calcRef.current) {
      calcRef.current = Desmos.GraphingCalculator(desmosRef.current, {
        expressions: true,
        zoomButtons: true,
      });
    }
  }, []);

  useEffect(() => {
    if (calcRef.current) {

      calcRef.current.setBlank();

      if (equation) {
        calcRef.current.setExpression({
          id: "main",
          latex: equation.replace(/\^/g, "^"), 
          color: Desmos.Colors.BLUE,
        });
      }

      
      if (points && points.length > 0) {
        points.forEach((p, i) => {
          if (typeof p.xNew === "number") {
            calcRef.current.setExpression({
              id: "point" + i,
              latex: `(${p.xNew.toFixed(6)}, 0)`, 
              color: Desmos.Colors.RED,
              pointStyle: Desmos.Styles.CROSS,
              showLabel: true,
              label: `x${i + 1}`,
            });
          }
        });
      }
    }
  }, [equation, points]);

  return <div ref={desmosRef} style={{ width: "100%", height: "400px" }} />;
}

export default DesmosGraph;
