import React,{Component} from "react"
import  {Link} from "react-router-dom";
import DesmosGraph from "./DesmosGraph";
import Secant from "../../utils/Secant";
class SecantMethod extends Component{


     constructor(props) {
    super(props);
    this.state = {
      Equation: "x^3 - x - 2",
      x0: 1,
      x1: 2,
      answer: null,
      steps: [],
    };
  }

      handleChange = (e, field) => {
    this.setState({
      [field]: e.target.type === "number" ? +e.target.value : e.target.value,
    });
  };


    calculate = () => {
    const { Equation, x0, x1 } = this.state;
    const method = new Secant(Equation, x0, x1, 0.000001, 100);
    const { root, steps } = method.calculate();
    this.setState({ answer: root, steps: steps });
  };


    render(){

         const { Equation, x0, x1, answer, steps } = this.state;

        return(
            <>
                <Link to="/" style={{fontSize:20}}>กลับหน้าแรก</Link>
                
                <h1 style={{color:'blueviolet'}}>Secant Method</h1>
                <h2>สมการ</h2>
                <input type="text" value={Equation} onChange={(e) => this.handleChange(e, "Equation")}></input>
                <h2>x0</h2>
                <input type="number" value={x0} onChange={(e) => this.handleChange(e, "x0")}></input>
                <h2>x1</h2>
                <input type="number" value={x1} onChange={(e) => this.handleChange(e, "x1")}></input>
                <h2></h2>
                <button onClick={this.calculate}>คํานวน</button>
                <h1>{answer}</h1>
                <DesmosGraph equation={Equation} points={steps} />

                  <table border="1" cellPadding="6" style={{ borderCollapse: "collapse" }}>
              <thead>
                <tr>
                  <th>รอบ</th>
                  <th>x₀</th>
                  <th>x₁</th>
                  <th>f(x₀)</th>
                  <th>f(x₁)</th>
                  <th>x₂</th>
                  <th>Error</th>
                </tr>
              </thead>
              <tbody>
                {steps.map((s, i) => (
                  <tr key={i}>
                    <td>{s.iter}</td>
                    <td>{s.x0.toFixed(6)}</td>
                    <td>{s.x1.toFixed(6)}</td>
                    <td>{s.fx0.toFixed(6)}</td>
                    <td>{s.fx1.toFixed(6)}</td>
                    <td>{s.x2.toFixed(6)}</td>
                    <td>{s.error.toExponential(3)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
            </>
          
        )   
    }
}
export default SecantMethod;

