import React, { Component } from "react";
import NewtonRaphson from "../../utils/NewtonRaphson";
import DesmosGraph from "./DesmosGraph";
import { Link } from "react-router-dom";



class NewtonRaphsonMethod extends Component{
    constructor(props){
        super(props);
        this.state={
            Equation: "x^3-x-2",  
            x0: 1,                    
            answer: null,
            steps: [],
        }
    }

    handleChange = (e, field) => {
        this.setState({
        [field]: e.target.type === "number" ? +e.target.value : e.target.value,
        });
    };

    Calculate = ()=>{

        const { Equation, x0 } = this.state;

        const method = new NewtonRaphson(Equation, x0);

        const{root,steps}= method.calculate();

        this.setState({answer:root,steps:steps});

    }

    render(){

            const{Equation,x0,answer}=this.state;

        return(
            
            <div style={{maxWidth: "1000px", margin: "40px auto", fontFamily: "Arial, sans-serif"}}>
                <nav>
                    <Link  to="/" style={{margin: "10px", fontSize: 25}}>• กลับหน้าแรก</Link>
                </nav>

                <div style={{textAlign:"center"}}>

                    <h2 style={{color: "blueviolet", fontSize: "36px", fontWeight: "bold", marginBottom: "20px"}} >NewtonRaphson Method</h2>
                     
                    <h2>สมการ</h2>

                    <input type="text" value={Equation} onChange={(e)=>this.handleChange(e,"Equation")}></input>

                    <h2>ค่าเริ่มต้น</h2>

                    <input type="number" value={x0} onChange={(e)=>this.handleChange(e,"x0")}></input>

                    <div style={{marginBottom:"10px"}}></div>
                    <button onClick={this.Calculate} style={{padding: "12px 25px",backgroundColor: "#4CAF50", color: "white", border: "none", borderRadius: "8px",fontSize: "16px",fontWeight: "bold",cursor: "pointer",boxShadow: "2px 4px 8px rgba(0,0,0,0.2)", transition: "0.3s"}}>คํานวน</button>
                    
                    <div  style={{marginBottom: "20px"}}>  </div>
                    <h2>คําตอบที่ได้</h2>
                    <h2>{answer}</h2>
                    <DesmosGraph equation={Equation} points={[]} />
                  
                    

{this.state.steps.length > 0 ? (
  <table
    border="1"
    cellPadding="8"
    style={{ margin: "20px auto", borderCollapse: "collapse", textAlign: "center" }}
  >
    <thead style={{ background: "#f2f2f2" }}>
      <tr>
        <th>รอบ</th>
        <th>X เดิม</th>
        <th>f(x)</th>
        <th>f'(x)</th>
        <th>X ใหม่</th>
        <th>Error</th>
      </tr>
    </thead>
    <tbody>
      {this.state.steps.map((s, i) => (
        <tr key={i}>
          <td>{s.iter}</td>
          <td>{s.x.toFixed(6)}</td>
          <td>{s.fx.toFixed(6)}</td>
          <td>{s.fdx.toFixed(6)}</td>
          <td>{s.xNew.toFixed(6)}</td>
          <td>{s.error.toExponential(2)}</td>
        </tr>
      ))}
    </tbody>
  </table>
) : (
  <p style={{ color: "#888" }}>ยังไม่มีข้อมูลการคำนวณ</p>
)}






                    
                </div>
            </div>
        )
    }
}

export default NewtonRaphsonMethod;