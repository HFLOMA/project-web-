import React, { Component } from "react";
import OnePointIteration from "../../utils/OnePointIteration"; 
import DesmosGraph from "./DesmosGraph";
import { Link } from "react-router-dom";

class OnePointIterationMethod extends Component {
  constructor(props) {
    super(props);
    this.state = {
      Equation: "x^4-13",  
      x0: 1,                     
      answer: 0,
      iterations: [],
    };
  }

  handleChange = (e, field) => {
    this.setState({
      [field]: e.target.type === "number" ? +e.target.value : e.target.value,
    });
  };

  Calculate = () => {
    const { Equation, x0 } = this.state;
    const method = new OnePointIteration(Equation, x0); 
    const { root, steps } = method.calculate();
    this.setState({ answer: root, iterations: steps });
  };

  render() {
    const { Equation, x0, answer, iterations } = this.state;

    return (
      <div style={{ maxWidth: "1000px", margin: "40px auto", fontFamily: "Arial, sans-serif" }}>
        <nav>
          <Link to="/" style={{ margin: "10px", fontSize: 25 }}>
            • กลับหน้าแรก
          </Link>
        </nav>

        <div style={{ textAlign: "center" }}>
          <h1 style={{ color: "blueviolet", fontSize: "36px", fontWeight: "bold", marginBottom: "20px" }}>
            One-Point Iteration Method
          </h1>

          <h2>สมการ</h2>
          <input
            type="text"
            value={Equation}
            onChange={(e) => this.handleChange(e, "Equation")}
          />

          <h2>X₀ </h2>
          <input
            type="number"
            value={x0}
            onChange={(e) => this.handleChange(e, "x0")}
          />

          <div style={{ marginTop: "20px" }}>
            <button onClick={this.Calculate}>คำนวณ</button>
          </div>

          <h3>คำตอบที่ได้</h3>
          {iterations.length > 0 ? (
            <h2 style={{ color: "green", fontSize: "30px", fontWeight: "bold" }}>
              {answer.toFixed(10)}
            </h2>
          ) : (
            <h2 style={{ color: "gray" }}>ยังไม่มีคำตอบ</h2>
          )}

          {iterations.length > 0 && (
            <table border="1" cellPadding="5" style={{ margin: "20px auto", borderCollapse: "collapse" }}>
              <thead style={{ background: "#f2f2f2" }}>
                <tr>
                  <th>Iteration</th>
                  <th>Xold</th>
                  <th>Xnew</th>
                  <th>Error</th>
                </tr>
              </thead>
              <tbody>
                {iterations.map((s, i) => (
                  <tr key={i}>
                    <td>{s.iter}</td>
                    <td>{typeof s.xOld === "number" ? s.xOld.toFixed(6) : s.xOld}</td>
                    <td>{typeof s.xNew === "number" ? s.xNew.toFixed(6) : s.xNew}</td>
                    <td>{typeof s.error === "number" ? s.error.toFixed(6) : s.error}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}

          <DesmosGraph equation={Equation} points={iterations} />
        </div>
      </div>
    );
  }
}

export default OnePointIterationMethod;
