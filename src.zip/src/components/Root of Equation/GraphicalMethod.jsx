import React, { Component } from "react";
import Graphical from "../../utils/Graphical";
import { Link } from "react-router-dom";
import DesmosGraph from "./DesmosGraph";

class GraphicalMethod extends Component {
  constructor(props) {
    super(props);
    this.state = {
      Equation: "43*x - 180",
      roots: null,
    };
  }
  handleChange = (e, field) => {
    this.setState({
      [field]:
        e.target.type === "number" ? +e.target.value : e.target.value,
    });
  };
  calculate = () => {
    const { Equation } = this.state;
    const g = new Graphical(Equation);
     const roots = g.calculate(0, 10, 0.0001);
    this.setState({ roots });
  };

  render() {
   
    const { Equation,roots } = this.state;

    return (
    <div style={{maxWidth: "1000px",margin: "40px auto",fontFamily: "Arial, sans-serif",}}>

         <Link to="/" style={{fontSize:25}}>• กลับหน้าแรก</Link>
        
        <div style={{textAlign:"center"}}>
              <h1 style={{ color: "blueviolet",
              fontSize: "36px",
              fontWeight: "bold",
              marginBottom: "20px",}}>Graphical Method</h1>

               <h2>สมการ</h2>
                
              <input style={{}} type="text" value={Equation} onChange={(e) => this.handleChange(e, "Equation")}></input>

               <div style={{ marginTop: "20px" }}>
                <button  
                onClick={this.calculate} 
                style={{padding: "12px 25px",
      backgroundColor: "#4CAF50", 
      color: "white",             
      border: "none",            
      borderRadius: "8px",        
      fontSize: "16px",
      fontWeight: "bold",
      cursor: "pointer",          
      boxShadow: "2px 4px 8px rgba(0,0,0,0.2)", 
      transition: "0.3s"}}>คํานวน</button>
        <div style={{ marginTop: "20px" }}></div>
        <h2>คําตอบ</h2>

       <h2 style={{ color: "green", fontSize: "30px", fontWeight: "bold" }}>
       {roots}
      </h2>

        
      <DesmosGraph equation={Equation} points={roots} />
      
               </div>
              

              
        </div>

                
         
    </div>
    );
  }
}

export default GraphicalMethod;
