import * as math from "mathjs";

class OnePointIteration {
  constructor(gx, x0, tol = 0.000001, maxIter = 1000) {
    this.gx = gx;      
    this.x0 = x0;       
    this.tol = tol;
    this.maxIter = maxIter;
    this.steps = [];
    this.root = null;
  }

  calculate() {
    let Iteration = 0;
    let xOld = this.x0;
    let xNew = null;
    let error = 1;

    do {
      Iteration++;

      
      xNew = math.evaluate(this.gx, { x: xOld });

      if (Iteration > 1) {
        error = Math.abs((xNew - xOld) / xNew);
      }

      this.steps.push({
        iter: Iteration,
        xOld: xOld,
        xNew: xNew,
        error: Iteration === 1 ? "-" : error,
      });

      xOld = xNew;
    } while (error > this.tol && Iteration < this.maxIter);

    this.root = xNew;
    return { root: this.root, steps: this.steps };
  }
}

export default OnePointIteration;
