import * as math from "mathjs";

class NewtonRaphson {
  constructor(expr, x0, tol = 0.000001, maxIter = 100) {
    this.expr = expr;
    this.x0 = x0;
    this.tol = tol;
    this.maxIter = maxIter;
    this.steps = []; 
  }

  calculate() {
    let x = this.x0;
    let fx, fdx, xNew;
    let iter = 0;

    do {
      fx = math.evaluate(this.expr, { x });
      fdx = math.derivative(this.expr, "x").evaluate({ x });

      xNew = x - fx / fdx;
      iter++;

      this.steps.push({
        iter,
        x,
        fx,
        fdx,
        xNew,
        error: Math.abs(xNew - x),
      });

      if (Math.abs(xNew - x) < this.tol) break;
      x = xNew;
    } while (iter < this.maxIter);

    return { root: xNew, steps: this.steps };
  }
}

export default NewtonRaphson;
 