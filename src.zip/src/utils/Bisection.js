import * as math from "mathjs";

class Bisection {
  constructor(expr, xl, xr, tol = 0.000001) {
    this.expr = expr;
    this.xl = xl;
    this.xr = xr;
    this.tol = tol;
    this.steps = [];
    this.root = null;
  }

  calculate() {
    let Iteration = 0;
    let left = this.xl;
    let right = this.xr;
    let newX = null;
    let oldX;
    let error = 1;
    let fl, fm;

    do {
      Iteration++;
      oldX = newX;
      newX = (left + right) / 2;

      fl = math.evaluate(this.expr, { x: left });
      fm = math.evaluate(this.expr, { x: newX });

      if (oldX !== null) {
        error = Math.abs((newX - oldX) / newX);
      }

      this.steps.push({
        iter: Iteration,
        xl: left,
        xr: right,
        xm: newX,
        y: fm,
        error: Iteration === 1 ? "-" : error,
      });

      if (fl * fm > 0) {
        left = newX;
      } else {
        right = newX;
      }
    } while (error > this.tol);

    this.root = newX;
    return { root: this.root, steps: this.steps };
  }
}

export default Bisection;
