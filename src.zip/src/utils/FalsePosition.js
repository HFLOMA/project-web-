import * as math from "mathjs";

class FalsePosition {
  constructor(expr, xl, xr, tol = 0.000001, maxIter = 1000) {
    this.expr = expr;
    this.xl = xl;
    this.xr = xr;
    this.tol = tol;
    this.maxIter = maxIter;
    this.steps = [];
    this.root = null;
  }

  calculate() {
    let Iteration = 0;
    let left = this.xl;
    let right = this.xr;
    let newX = null;
    let oldX = null;
    let error = 1;
    let fl, fr, fm;

    do {
      Iteration++;
      oldX = newX;

      fl = math.evaluate(this.expr, { x: left });
      fr = math.evaluate(this.expr, { x: right });

      if (fr === fl) {
        break;
      }

      newX = (left * fr - right * fl) / (fr - fl);
      fm = math.evaluate(this.expr, { x: newX });

      if (oldX !== null) {
        error = Math.abs((newX - oldX) / newX);
      }

      this.steps.push({
        iter: Iteration,
        xl: left,
        xr: right,
        xm: newX,
        y: fm,
        error: Iteration === 1 ? "-" : error,
      });

      if (fl * fm < 0) {
        right = newX;
      } else {
        left = newX;
      }
    } while (error > this.tol && Iteration < this.maxIter);

    this.root = newX;
    return { root: this.root, steps: this.steps };
  }
}

export default FalsePosition;
