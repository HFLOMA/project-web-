import * as math from "mathjs";

class Secant {
  constructor(expr, x0, x1, tol = 0.000001, maxIter = 100) {
    this.expr = expr;     
    this.x0 = x0;          
    this.x1 = x1;        
    this.tol = tol;       
    this.maxIter = maxIter;
    this.steps = [];      
  }

  calculate() {
    let x0 = this.x0;
    let x1 = this.x1;
    let x2, fx0, fx1;
    let iter = 0;

    do {
      fx0 = math.evaluate(this.expr, { x: x0 });
      fx1 = math.evaluate(this.expr, { x: x1 });

    
      x2 = x1 - fx1 * ((x1 - x0) / (fx1 - fx0));

     
      this.steps.push({
        iter: iter + 1,
        x0: x0,
        x1: x1,
        fx0: fx0,
        fx1: fx1,
        x2: x2,
        error: Math.abs((x2 - x1)/x2),
      });

      if (Math.abs((x2 - x1)/x2) < this.tol) break;

      x0 = x1;
      x1 = x2;
      iter++;

    } while (iter < this.maxIter);

    return { root: x2, steps: this.steps };
  }
}

export default Secant;
