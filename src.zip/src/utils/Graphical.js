import * as math from "mathjs";

class Graphical {
  constructor(expr) {
    this.expr = expr;
  }

  calculate(start = -100, end = 100, step = 0.001) {
    let root = null;
    let x1 = start;
    let y1 = math.evaluate(this.expr, { x: x1 });
    let x2 = x1 + step;
    let y2;

    do {
      y2 = math.evaluate(this.expr, { x: x2 });

      if (y1 * y2 <= 0) {
        root = (x1 + x2) / 2;
        break;
      }

      x1 = x2;
      y1 = y2;
      x2 += step;
    } while (x2 <= end);

    return root; 
  }
}

export default Graphical;
